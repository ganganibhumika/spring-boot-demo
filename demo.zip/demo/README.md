API descripion

1). Registration API for System user (Admin)

URL :: http://localhost:8080/api/auth/register Method :: POST Request Parameter:: (json)

{ "firstname": "admin", "lastname": "system", "email": "admin@gmail.com", "username": "admin", "password" : "Test@123"

}

2). Login

URL :: http://localhost:8080/api/auth/login Method :: POST Request Parameter:: (json)

{

"username": "admin", "password":"Test@123"

}